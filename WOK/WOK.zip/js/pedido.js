function añade(id) {
	var captura=document.getElementsByClassName(id);
	alert(captura);
}